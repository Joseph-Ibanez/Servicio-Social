
Aqui van las instrucciones para compilar mi tesis.

Cuando descomprimas la carpeta vas a encontrar los siguientes archivos:

1.  Tesis_doctorado.tex
2.  Cap1.tex
3.  Cap2.tex
4.  Cap3.tex
5.  Cap4.tex
6.  Cap5.tex
7.  Cap6.tex 
8.  Cap7.tex
9.  Cap8.tex
10. Cap9.tex 
11. Apendice.tex
12. bibliografia.bib

Tambien vas a encontrar la carpeta "Figs",
que contiene las graficas para cada capitulo y
los logotipos de la UMSNH y del IFM.

El UNICO archivo que tienes que compilar es Tesis_doctorado.tex.
Ese es el principal. Todos los demas los va a jalar desde el principal.
La unica razon para poner los capitulos en archivos separados es para
tener una mejor organizacion. Por ejemplo, cuando modificas algo en
Cap5.tex lo guardas, y para ver los cambios compilas Tesis_doctorado.tex.
El Apendice.tex es como cualquier otro capitulo.

El indice se genera automaticamente.

bibliografia.bib es un archivo de texto que contiene
todas las referencias bibliograficas. Puedes agregar los datos de tus
libros ahi, por ejemplo, y luego citarlos desde cualquier capitulo (puedes
ver muchos ejemplos de eso en mi tesis).

No se como funcione tu compilador de archivos LaTex,
pero normalmente, para compilar la bibliografia, uno tiene que
compilar primero normalmente usando el pquete pdflatex, luego usando
bibtex y luego otra vez (o dos) usando pdflatex.

Todos los archivos .out, .aux, .log, .blg, .gz y .toc que se
generan durante la compilacion son auxiliares y no te sirven,
asi que puedes borrarlos despues de compilar.

Cuando compiles mi tesis, encontraras ejemplos de como poner figuras y
tablas. Puedes modificar toda mi informacion
y sustituirla con la tuya, agregar o quitar capitulos, agregar o quitar
bibliografia, etc. Solo te recomiendo no modificar las primeras 66 lineas
del archivo Tesis_doctorado.tex para que no se descomponga el formato.
Puedes modificar a partir de donde dice "\begin{document}".

Avisame si tienes problemas.
